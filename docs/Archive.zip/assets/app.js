(() => {
  const root = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');
  const savedTheme = localStorage.getItem('rahsepar-theme');
  if (savedTheme) root.dataset.theme = savedTheme;
  themeToggle?.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('rahsepar-theme', root.dataset.theme);
  });

  const sidebar = document.getElementById('sidebar');
  document.getElementById('menuToggle')?.addEventListener('click', () => sidebar.classList.toggle('open'));
  document.querySelectorAll('.sidebar a').forEach(a => a.addEventListener('click', () => sidebar.classList.remove('open')));

  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const code = btn.closest('.code-card')?.querySelector('pre code')?.innerText || '';
      try { await navigator.clipboard.writeText(code); btn.textContent = 'کپی شد'; btn.classList.add('copied'); setTimeout(() => { btn.textContent='کپی'; btn.classList.remove('copied'); }, 1200); } catch (_) {}
    });
  });

  const sections = [...document.querySelectorAll('.doc-section')];
  const sideLinks = [...document.querySelectorAll('.sidebar a')];
  const observer = new IntersectionObserver(entries => {
    const visible = entries.filter(e => e.isIntersecting).sort((a,b) => b.intersectionRatio-a.intersectionRatio)[0];
    if (!visible) return;
    sideLinks.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + visible.target.id));
  }, { rootMargin: '-15% 0px -70% 0px', threshold:[0,.1,.5] });
  sections.forEach(s => observer.observe(s));

  const modal = document.getElementById('searchModal');
  const trigger = document.getElementById('searchTrigger');
  const input = document.getElementById('searchInput');
  const results = document.getElementById('searchResults');
  const searchData = sections.map(s => ({ id:s.id, title:s.dataset.title || s.querySelector('h2,h1')?.innerText || '', text:s.innerText.replace(/\s+/g,' ').trim() }));
  let selected = 0;
  function renderSearch(q='') {
    const query = q.trim().toLowerCase();
    const filtered = searchData.filter(x => !query || (x.title+' '+x.text).toLowerCase().includes(query)).slice(0,12);
    results.innerHTML = filtered.map((x,i) => `<a class="search-result ${i===selected?'selected':''}" href="#${x.id}" data-i="${i}"><b>${x.title}</b><small>${x.text.slice(0,150)}…</small></a>`).join('') || '<div class="search-result"><small>نتیجه‌ای پیدا نشد.</small></div>';
    results.querySelectorAll('a').forEach(a => a.addEventListener('click', closeSearch));
  }
  function openSearch(){ modal.hidden=false; selected=0; renderSearch(input.value); setTimeout(()=>input.focus(),0); }
  function closeSearch(){ modal.hidden=true; input.blur(); }
  trigger?.addEventListener('click', openSearch);
  modal?.addEventListener('click', e => { if(e.target===modal) closeSearch(); });
  input?.addEventListener('input', () => { selected=0; renderSearch(input.value); });
  document.addEventListener('keydown', e => {
    if (e.key==='/' && modal.hidden && !/input|textarea/i.test(document.activeElement?.tagName||'')) { e.preventDefault(); openSearch(); }
    else if(e.key==='Escape' && !modal.hidden) closeSearch();
    else if(!modal.hidden && (e.key==='ArrowDown'||e.key==='ArrowUp')) { e.preventDefault(); const count=results.querySelectorAll('a').length; if(!count)return; selected=(selected+(e.key==='ArrowDown'?1:-1)+count)%count; renderSearch(input.value); }
    else if(!modal.hidden && e.key==='Enter') { const a=results.querySelectorAll('a')[selected]; if(a){ location.hash=a.getAttribute('href'); closeSearch(); } }
  });

  const terminal = document.getElementById('terminalLive');
  const logLines = [
    ['20:17:31','info','● INFO','Running build command…'],
    ['20:17:36','ok','✔ SUCCESS','Build completed in 5s.'],
    ['20:17:37','info','● INFO','Creating ZIP archive…'],
    ['20:17:38','ok','✔ SUCCESS','Archive ready · 4.82 MB'],
    ['20:17:39','info','● INFO','Uploading release via FTP…'],
    ['20:17:44','ok','✔ SUCCESS','Upload completed.'],
    ['20:17:47','ok','✔ SUCCESS','Release is healthy.']
  ];
  let index = 0;
  function tick(){
    if(!terminal) return;
    if(index===0) terminal.innerHTML='';
    const [t,cls,label,msg]=logLines[index];
    const line=document.createElement('div'); line.className='terminal-line';
    line.innerHTML=`<span class="t">[${t}]</span> <span class="${cls}">${label}</span> <span class="label">${msg}</span>`;
    terminal.appendChild(line); index=(index+1)%logLines.length;
    if(index===0) setTimeout(tick,1500); else setTimeout(tick,520);
  }
  tick();
})();

  (() => {
    const tokenEl = document.getElementById("deployToken");
    const copyBtn = document.getElementById("deployTokenCopy");
    const regenerateBtn = document.getElementById(
      "deployTokenRegenerate"
    );

    if (!tokenEl || !copyBtn || !regenerateBtn) return;

    const TOKEN_LENGTH = 64;

    const ALPHABET =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
      "abcdefghijklmnopqrstuvwxyz" +
      "0123456789" +
      "-_";

    function generateSecureToken(length = TOKEN_LENGTH) {
      const output = [];

      /*
       * 256 % 64 === 0
       * بنابراین برای این alphabet با طول 64
       * modulo bias نداریم.
       */
      const bytes = new Uint8Array(length);

      crypto.getRandomValues(bytes);

      for (let i = 0; i < length; i++) {
        output.push(ALPHABET[bytes[i] & 63]);
      }

      return output.join("");
    }

    function generateToken() {
      const token = generateSecureToken();

      tokenEl.textContent = token;

      copyBtn.classList.remove("copied");

      const label = copyBtn.querySelector("span");

      if (label) {
        label.textContent = "کپی";
      }
    }

    async function copyToken() {
      const token = tokenEl.textContent.trim();

      if (!token) return;

      try {
        await navigator.clipboard.writeText(token);
      } catch {
        const textarea = document.createElement("textarea");

        textarea.value = token;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";

        document.body.appendChild(textarea);

        textarea.select();
        document.execCommand("copy");

        textarea.remove();
      }

      copyBtn.classList.add("copied");

      const label = copyBtn.querySelector("span");

      if (label) {
        label.textContent = "کپی شد";
      }

      setTimeout(() => {
        copyBtn.classList.remove("copied");

        if (label) {
          label.textContent = "کپی";
        }
      }, 1400);
    }

    regenerateBtn.addEventListener("click", generateToken);
    copyBtn.addEventListener("click", copyToken);

    generateToken();
  })();